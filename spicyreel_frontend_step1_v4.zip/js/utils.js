(function () {
// Chhote helper functions jo har screen mein kaam aate hain.
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const initial = name => (name || '?').trim().charAt(0).toUpperCase();
Spicy.utils = { esc, initial };
})();
