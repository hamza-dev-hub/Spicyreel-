(function () {
const { esc } = Spicy.utils;

// Neeche se khulne wali chhoti sheet: maloomat ya error dikhane ke liye.
function open(root, title, text) {
  const wrap = document.createElement('div');
  wrap.className = 'backdrop';
  wrap.innerHTML = `<div class="sheet" role="dialog" aria-label="${esc(title)}"><h2>${esc(title)}</h2>
    <p style="color:var(--mute);font-size:14px;line-height:1.5;margin:10px 0 16px">${esc(text)}</p><button class="btn ghost" id="ok">Close</button></div>`;
  root.appendChild(wrap);
  const close = () => wrap.remove();
  wrap.querySelector('#ok').onclick = close;
  wrap.addEventListener('click', e => { if (e.target === wrap) close(); });
}

Spicy.infoSheet = { open };
})();
