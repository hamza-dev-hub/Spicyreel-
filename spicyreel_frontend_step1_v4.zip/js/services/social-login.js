(function () {
const cfg = Spicy.config;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src; s.async = true; s.onload = resolve;
    s.onerror = () => reject(new Error('LOAD_FAILED'));
    document.head.appendChild(s);
  });
}

// Asli Google/Facebook login. Account ki list, email aur password ka check Google/Facebook
// ke apne popup mein hota hai. Hamari app ko password kabhi nazar nahi aata.
// Popup block na ho, is liye library app khulte hi pehle se load kar lete hain.
async function preload() {
  try {
    if (cfg.GOOGLE_CLIENT_ID && location.protocol !== 'file:') await loadScript('https://accounts.google.com/gsi/client');
    if (cfg.FACEBOOK_APP_ID && location.protocol !== 'file:') {
      await loadScript('https://connect.facebook.net/en_US/sdk.js');
      window.FB.init({ appId: cfg.FACEBOOK_APP_ID, cookie: true, xfbml: false, version: 'v21.0' });
    }
  } catch { /* internet nahi ho to click par error dikhayenge */ }
}

function guard(id) {
  if (!id) throw new Error('NOT_CONFIGURED');
  if (location.protocol === 'file:') throw new Error('FILE_ORIGIN');
}

async function signInGoogle() {
  guard(cfg.GOOGLE_CLIENT_ID);
  if (!window.google?.accounts?.oauth2) await loadScript('https://accounts.google.com/gsi/client');
  const token = await new Promise((resolve, reject) => {
    const client = window.google.accounts.oauth2.initTokenClient({
      client_id: cfg.GOOGLE_CLIENT_ID,
      scope: 'openid email profile',
      prompt: 'select_account',               // hamesha asli account ki list dikhao
      callback: r => (r.error ? reject(new Error(r.error)) : resolve(r.access_token)),
      error_callback: e => reject(new Error(e.type || 'popup_closed')),
    });
    client.requestAccessToken();
  });
  const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: 'Bearer ' + token } });
  if (!res.ok) throw new Error('PROFILE_FAILED');
  const u = await res.json();
  return { name: u.name || '', email: u.email || '', photo: u.picture || '', provider: 'Google' };
}

async function signInFacebook() {
  guard(cfg.FACEBOOK_APP_ID);
  if (!window.FB) throw new Error('LOAD_FAILED');
  await new Promise((resolve, reject) =>
    window.FB.login(r => (r.authResponse ? resolve(r.authResponse) : reject(new Error('cancelled'))), { scope: 'public_profile,email', auth_type: 'reauthenticate' }));
  const u = await new Promise(resolve => window.FB.api('/me', { fields: 'name,email,picture.width(200)' }, resolve));
  if (!u || u.error) throw new Error('PROFILE_FAILED');
  return { name: u.name || '', email: u.email || '', photo: u.picture?.data?.url || '', provider: 'Facebook' };
}

Spicy.socialLogin = { preload, signInGoogle, signInFacebook };
})();
