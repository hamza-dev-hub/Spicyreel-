(function () {
// Username ke qaide.
const RESERVED = ['admin', 'spicyreel', 'support', 'official', 'help'];

function checkUsernameFormat(u) {
  if (u.length < 3) return 'At least 3 characters';
  if (u.length > 20) return 'At most 20 characters';
  if (!/^[a-z0-9._]+$/.test(u)) return 'Use only lowercase letters, numbers, . and _';
  return '';
}

// DEMO: asli check backend se hoga (GET /users/check?username=...)
async function isUsernameAvailable(u) {
  await new Promise(r => setTimeout(r, 300));
  return !RESERVED.includes(u);
}

Spicy.auth = { checkUsernameFormat, isUsernameAvailable };
})();
