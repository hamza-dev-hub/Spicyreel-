(function () {
// App ka data (login, profile). Abhi browser/phone ki local storage mein save hota hai.
// Backend jurne ke baad ye data server se aayega.
const KEY = 'spicyreel.v1';
let data = load();
function load() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } }
const getState = () => data;
function setState(patch) {
  data = { ...data, ...patch };
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* storage full ya band */ }
}
function clearState() { data = {}; try { localStorage.removeItem(KEY); } catch {} }
Spicy.state = { getState, setState, clearState };
})();
