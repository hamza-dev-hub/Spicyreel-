// Yahan aap apni Google aur Facebook ki IDs likhte hain (README mein tareeqa hai).
// Jab tak ye khali hain, login button batata hai ke setup baqi hai. Koi nakli account nahi dikhta.
Spicy.config = {
  GOOGLE_CLIENT_ID: '',   // misal: '1234567890-abc123.apps.googleusercontent.com'
  FACEBOOK_APP_ID: '',    // misal: '1234567890123456'
};
