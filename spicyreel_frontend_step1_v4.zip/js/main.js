// App yahan se shuru hota hai. Naya screen: uski file banayein, index.html mein <script> jorein,
// aur us file ke aakhir mein Spicy.screens.<naam> = { render }; likhein.
(function () {
  const { getState } = Spicy.state;
  const screens = Spicy.screens;
  const root = document.getElementById('app');

  function navigate(name) {
    root.innerHTML = '';
    screens[name].render(root, navigate);
  }

  Spicy.socialLogin.preload();

  const s = getState();
  navigate(s.profile ? 'home' : s.user ? 'setup' : 'welcome');
})();
