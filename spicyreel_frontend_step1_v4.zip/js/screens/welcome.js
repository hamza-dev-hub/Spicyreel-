(function () {
const info = Spicy.infoSheet;
const { setState } = Spicy.state;
const { signInGoogle, signInFacebook } = Spicy.socialLogin;

const ICON_GOOGLE = `<svg width="24" height="24" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.5-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>`;
const ICON_FB = `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#1877F2"/><path fill="#fff" d="M16.7 15.5l.5-3.5h-3.3V9.8c0-1 .5-1.9 2-1.9h1.5V4.9s-1.4-.2-2.7-.2c-2.7 0-4.5 1.6-4.5 4.6V12H7.1v3.5h3.1V24h3.7v-8.5h2.8z"/></svg>`;
const ICON_MAIL = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="2.5" y="4.5" width="19" height="15" rx="2"/><path d="M3 6l9 7 9-7"/></svg>`;

// Login ke dauran jo masle aa sakte hain, unka saaf paigham.
function explain(root, provider, err) {
  const m = err.message;
  if (m === 'NOT_CONFIGURED') return info.open(root, `${provider} login is not set up yet`,
    `Add your ${provider === 'Google' ? 'Google Client ID' : 'Facebook App ID'} in js/config.js. The README explains how to get it (it is free).`);
  if (m === 'FILE_ORIGIN') return info.open(root, 'Open the app through a server',
    `${provider} login does not work when index.html is opened by double-click. In VS Code, right-click index.html and choose "Open with Live Server", then try again.`);
  if (m === 'LOAD_FAILED') return info.open(root, 'Could not reach ' + provider, 'Check your internet connection and try again.');
  if (['popup_closed', 'popup_failed_to_open', 'cancelled', 'access_denied'].includes(m)) {
    if (m === 'popup_failed_to_open') info.open(root, 'Popup was blocked', 'Allow popups for this site in your browser, then try again.');
    return; // user ne khud popup band kiya
  }
  info.open(root, 'Login failed', `${provider} did not sign you in (${m}). Please try again.`);
}

// Screen 1: Login / Sign up
function render(root, navigate) {
  root.innerHTML = `<main class="login">
    <div class="brand"><span aria-hidden="true">🌶️</span> Spicyreel</div>
    <section class="card" aria-labelledby="lt">
      <h1 id="lt">Log in or sign up in seconds</h1>
      <p class="lead">Use your email or another service to continue with Spicyreel (it’s free!)</p>
      <button class="opt" data-p="Google">${ICON_GOOGLE}<span>Continue with Google</span></button>
      <button class="opt" data-p="Facebook">${ICON_FB}<span>Continue with Facebook</span></button>
      <button class="opt" data-p="email">${ICON_MAIL}<span>Continue with email</span></button>
      <button class="more" id="more">Continue another way</button>
      <p class="legal">By continuing, you agree to Spicyreel’s <a href="#" data-i="terms">Terms of Use</a>. Read our <a href="#" data-i="privacy">Privacy Policy</a>.</p>
    </section></main>`;

  const run = async (btn, provider, fn) => {
    btn.disabled = true;
    try { setState({ user: await fn() }); navigate('setup'); }
    catch (e) { btn.disabled = false; explain(root, provider, e); }
  };
  const $ = s => root.querySelector(s);
  $('[data-p="Google"]').onclick = e => run(e.currentTarget, 'Google', signInGoogle);
  $('[data-p="Facebook"]').onclick = e => run(e.currentTarget, 'Facebook', signInFacebook);
  $('[data-p="email"]').onclick = () =>
    info.open(root, 'Email login', 'Email and password sign-up needs the backend. It will be added in the backend step.');
  $('#more').onclick = () => info.open(root, 'More ways to continue', 'Phone number and Apple sign-in will be added in a later step.');
  root.querySelectorAll('.legal a').forEach(a => a.onclick = e => {
    e.preventDefault();
    info.open(root, a.dataset.i === 'terms' ? 'Terms of Use' : 'Privacy Policy', 'This page will be written before the app is published.');
  });
}

Spicy.screens.welcome = { render };
})();
