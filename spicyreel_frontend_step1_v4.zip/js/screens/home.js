(function () {
const { getState, clearState } = Spicy.state;
const { esc, initial } = Spicy.utils;

// Screen 3: abhi sirf placeholder. Agla step: reel feed yahan banega.
function render(root, navigate) {
  const { profile: p, user } = getState();
  root.innerHTML = `<main class="homebox">
    <div class="avatar">${p.photo ? `<img alt="" src="${p.photo}">` : esc(initial(p.name))}</div>
    <h2>Welcome, ${esc(p.name)}</h2><p class="hint">@${esc(p.username)}${user.email ? ' · ' + esc(user.email) : ''}</p>
    ${p.bio ? `<p>${esc(p.bio)}</p>` : ''}
    <div class="note">Login and profile setup are working. Next step: build the reel feed on this screen.</div>
    <button class="btn ghost" id="out">Log out</button></main>`;
  root.querySelector('#out').onclick = () => { clearState(); navigate('welcome'); };
}
Spicy.screens.home = { render };
})();
