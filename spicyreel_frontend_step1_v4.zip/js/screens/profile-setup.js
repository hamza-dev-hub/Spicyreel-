(function () {
const { getState, setState } = Spicy.state;
const { checkUsernameFormat, isUsernameAvailable } = Spicy.auth;
const { esc, initial } = Spicy.utils;

// Screen 2: Profile setup (naam, username, bio, photo)
function render(root, navigate) {
  const { user } = getState();
  const suggest = ((user.email || user.name || 'user').split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9._]/g, '').slice(0, 20);
  let photo = '';
  root.innerHTML = `<main class="setup"><h2>Set up your profile</h2><p class="sub">This is how people will see you on Spicyreel.</p>
    <div class="center"><div class="avatar" id="av">${esc(initial(user.name))}</div>
      <label class="link">Add photo<input id="ph" type="file" accept="image/*" hidden></label><p class="hint bad" id="pherr"></p></div>
    <label class="field"><span>Name</span><input id="name" maxlength="40" value="${esc(user.name)}"></label>
    <label class="field"><span>Username</span><input id="un" maxlength="20" autocapitalize="none" autocomplete="off" value="${esc(suggest)}"><p class="hint" id="unh"></p></label>
    <label class="field"><span>Bio (optional)</span><textarea id="bio" rows="2" maxlength="120" placeholder="Tell people about you"></textarea></label>
    <button class="btn" id="done" disabled>Finish</button></main>`;
  const $ = s => root.querySelector(s);

  $('#ph').onchange = e => {
    const f = e.target.files[0]; if (!f) return;
    if (f.size > 1024 * 1024) { $('#pherr').textContent = 'Photo must be under 1 MB'; return; }
    $('#pherr').textContent = '';
    const r = new FileReader();
    r.onload = () => { photo = r.result; $('#av').innerHTML = `<img alt="Your photo" src="${photo}">`; };
    r.readAsDataURL(f);
  };

  let timer;
  const checkName = () => {
    const u = $('#un').value.trim().toLowerCase(), h = $('#unh');
    $('#done').disabled = true; clearTimeout(timer);
    const bad = checkUsernameFormat(u);
    if (bad) { h.className = 'hint bad'; h.textContent = bad; return; }
    h.className = 'hint'; h.textContent = 'Checking…';
    timer = setTimeout(async () => {
      const ok = await isUsernameAvailable(u);
      if (u !== $('#un').value.trim().toLowerCase()) return; // user ne tab tak kuch aur likh diya
      h.className = 'hint ' + (ok ? 'ok' : 'bad');
      h.textContent = ok ? `@${u} is available` : `@${u} is taken. Try another.`;
      $('#done').disabled = !ok;
    }, 350);
  };
  $('#un').oninput = checkName; checkName();

  $('#done').onclick = () => {
    const name = $('#name').value.trim();
    if (!name) { $('#name').focus(); return; }
    setState({ profile: { name, username: $('#un').value.trim().toLowerCase(), bio: $('#bio').value.trim(), photo } });
    navigate('home');
  };
}
Spicy.screens.setup = { render };
})();
